# CrazyTownS3 Modpack Updater

# === CONFIG ===
$instanceName = "CrazyTownS3"
$baseDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$localVersionFile = "$baseDir\version.txt"
$remoteVersionURL = "https://raw.githubusercontent.com/SandBox-Collective/VillageNormalS3-Modpack/main/version.txt"
$remoteZipURL = "https://github.com/SandBox-Collective/VillageNormalS3-Modpack/raw/main/CrazyTownS3.zip"
$tempZipPath = "$env:TEMP\CrazyTownS3_Update.zip"

# === FUNCTIONS ===
Function Get-RemoteVersion {
    try {
        return Invoke-RestMethod -Uri $remoteVersionURL -UseBasicParsing
    } catch {
        Write-Host "Failed to fetch remote version." ; return $null
    }
}

Function Download-And-Install {
    Write-Host "Updating CrazyTownS3..."
    Invoke-WebRequest -Uri $remoteZipURL -OutFile $tempZipPath -UseBasicParsing

    # Extract contents, preserve saves
    $tempExtractDir = "$env:TEMP\CrazyTownS3_Extracted"
    if (Test-Path $tempExtractDir) { Remove-Item $tempExtractDir -Recurse -Force }
    Expand-Archive -Path $tempZipPath -DestinationPath $tempExtractDir -Force

    # Define conditionally skipped paths
    $conditionallySkipped = @(
        "options.txt",
        "servers.dat",
        "optionsof.txt",
        "usercache.json",
        "launcher_profiles.json",
        "config\voicechat",
        "config\journeymap"
    )

    # Remove old mods from mods folder
    $modsFolder = Join-Path $baseDir "mods"
    if (Test-Path $modsFolder) {
        Write-Host "Removing old mods from the mods folder..."
        Remove-Item -Path "$modsFolder\*" -Force
    } else {
        Write-Host "Mods folder does not exist, creating one..."
        New-Item -ItemType Directory -Path $modsFolder | Out-Null
    }

    # Copy everything, but skip some files/folders if they already exist in instance
    Get-ChildItem -Path $tempExtractDir -Recurse | ForEach-Object {
        $relPath = $_.FullName.Substring($tempExtractDir.Length).TrimStart('\')
        $targetPath = Join-Path $baseDir $relPath

        $shouldSkip = $false
        foreach ($skipPath in $conditionallySkipped) {
            if ($relPath -ieq $skipPath -or $relPath.StartsWith("$skipPath\")) {
                if (Test-Path $targetPath) {
                    $shouldSkip = $true
                    break
                }
            }
        }

        # If not skipping, copy the file/folder
        if (-not $shouldSkip) {
            if ($_.PSIsContainer) {
                if (!(Test-Path $targetPath)) { New-Item -ItemType Directory -Path $targetPath | Out-Null }
            } else {
                # Only copy mods into the mods folder
                if ($relPath -like "mods\*") {
                    Copy-Item $_.FullName -Destination $targetPath -Force
                } else {
                    Copy-Item $_.FullName -Destination $targetPath -Force
                }
            }
        }
    }

    # Clean up
    Remove-Item $tempZipPath -Force
    Remove-Item $tempExtractDir -Recurse -Force
    Write-Host "Update complete."

    # Update version.txt with the new version
    Write-Host "Updating version file..."
    Set-Content -Path $localVersionFile -Value $remoteVersion
    Write-Host "Version file updated to $remoteVersion."
}

# === MAIN ===
$remoteVersion = Get-RemoteVersion
if (-not $remoteVersion) { return }

if (Test-Path $localVersionFile) {
    $localVersion = Get-Content $localVersionFile -ErrorAction SilentlyContinue
} else {
    $localVersion = "0.0.0"
}

if ($localVersion -ne $remoteVersion) {
    Download-And-Install
} else {
    # Write-Host "Modpack up to date."
}
